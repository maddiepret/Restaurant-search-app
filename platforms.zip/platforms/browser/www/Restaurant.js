//create object
function Restuarant(name, location, rating, priceLevel, photo) {
    this.name = name;
    this.location = location;
    this.rating = rating;
    thia.priceLevel = priceLevel;
    this.photo = photo;

}